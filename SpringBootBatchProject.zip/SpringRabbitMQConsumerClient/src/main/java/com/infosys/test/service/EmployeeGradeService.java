package com.infosys.test.service;

import com.infosys.test.model.Employee;

public interface EmployeeGradeService {
	
	public void insertEmployeeIntoTable(String tableName, Employee employee);

}
