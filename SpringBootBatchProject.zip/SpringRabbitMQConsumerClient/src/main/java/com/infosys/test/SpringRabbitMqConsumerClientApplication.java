package com.infosys.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRabbitMqConsumerClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRabbitMqConsumerClientApplication.class, args);
	}

}
