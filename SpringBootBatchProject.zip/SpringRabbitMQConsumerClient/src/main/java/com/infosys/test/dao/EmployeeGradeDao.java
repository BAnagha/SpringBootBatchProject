package com.infosys.test.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.annotation.ManagedBean;

import com.infosys.test.model.Employee;
import com.infosys.test.util.MySQLJDBCUtil;

@ManagedBean
public class EmployeeGradeDao {

	public void insertEmployeeIntoTable(String tableName, Employee employee) {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		try {
			conn = MySQLJDBCUtil.getConnection();
			if(conn !=null) {
				preparedStatement = conn.prepareStatement("Insert into "+ tableName + " values (?,?,?,?,?,?,?,?)");
				preparedStatement.setLong(1,employee.getEmployeeNumber() );
				preparedStatement.setString(2, employee.getEmployeeName());
				preparedStatement.setString(3, employee.getEmployeeSection());
				preparedStatement.setString(4, employee.getEmployeeAddress());
				preparedStatement.setInt(5, employee.getEmployeeExperience());
				preparedStatement.setDouble(6, employee.getEmployeeSalary());
				preparedStatement.setDouble(7, employee.getEmployeeAnnualPay());
				preparedStatement.setDouble(8, employee.getEmployeeBonus());
				int result = preparedStatement.executeUpdate();
				if(result > 0) {
					System.out.println("Values inserted successfully in " + tableName);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
