package com.infosys.test.batchconfig;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.infosys.test.model.Employee;
import com.infosys.test.service.EmployeeGradeService;

@Component
public class MessageConsumer {
	
	private final double BASELINE = 120000;
	
	
	@Autowired
	EmployeeGradeService employeeGradeService;
	
	@RabbitListener(queues="employee-queue", concurrency = "4")
	public void receivedMessage(Employee employee) {
		System.out.println("Received Message: " + employee);
		if((employee.getEmployeeAnnualPay() + employee.getEmployeeBonus())  > BASELINE)
		{
			employeeGradeService.insertEmployeeIntoTable("grade_1_employees", employee);
		}
		else {
			employeeGradeService.insertEmployeeIntoTable("grade_2_employees", employee);
		}
		
	}
	
}