package com.infosys.test.batchconfig;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {

	public final static String queueName = "employee-queue";

	@Bean
	public ConnectionFactory rabbitMqconnection() {
		final CachingConnectionFactory rabbitConnectionFactory = new CachingConnectionFactory();
		rabbitConnectionFactory.setHost("localhost");
		rabbitConnectionFactory.setPort(5672);
		rabbitConnectionFactory.setUsername("guest");
		rabbitConnectionFactory.setPassword("guest");
		return rabbitConnectionFactory;
	}

	@Bean
	public Queue employeeQueue() {
		return new Queue(queueName,false);
	}

	@Bean
	public Queue replyQueue() {
		return new Queue("employee.reply.queue");
	}

	@Bean
	Binding binding() {
		return BindingBuilder.bind(employeeQueue()).to(new DirectExchange("amq.direct")).with("");
	}

	@Bean
	public RabbitTemplate rabbitTemplate() {
		RabbitTemplate rabbitTemplate = new RabbitTemplate(this.rabbitMqconnection());
		rabbitTemplate.setDefaultReceiveQueue(queueName);
		rabbitTemplate.setReplyAddress("reply/routeReply");
		return rabbitTemplate;
	}
}
