package com.infosys.test.service;

import javax.annotation.ManagedBean;

import org.springframework.beans.factory.annotation.Autowired;

import com.infosys.test.dao.EmployeeGradeDao;
import com.infosys.test.model.Employee;

@ManagedBean
public class EmployeeGradeServiceBean implements EmployeeGradeService {

	
	@Autowired
	EmployeeGradeDao employeeGradeDao;
	
	@Override
	public void insertEmployeeIntoTable(String tableName, Employee employee) {
		employeeGradeDao.insertEmployeeIntoTable(tableName, employee);
	}

}
