package com.infosys.test.batchconfig;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import com.infosys.test.model.Employee;
import com.infosys.test.model.SalaryInfo;

public class EmployeeItemProcessor implements ItemProcessor<Employee,Employee>{

	@Autowired
	public RestTemplate restTemplate;
	
	@Override
	public Employee process(Employee employee) throws Exception {

		//call api and get remaining details
		System.out.println("Employee :::: "+employee);
		SalaryInfo salInfo = restTemplate.getForObject("http://employee-salary-info/employee/salaryInfo/"+employee.getEmployeeNumber(),
				SalaryInfo.class);
		employee.setEmployeeSalary(salInfo.getEmployeeSalary());
		employee.setEmployeeAnnualPay(salInfo.getEmployeeAnnualPay());
		employee.setEmployeeBonus(salInfo.getEmployeeBonus());
		return employee;
	}

}
