//package com.infosys.test.batchconfig;
//
//import java.util.Objects;
//
//import org.springframework.batch.item.ItemReader;
//import org.springframework.batch.item.ParseException;
//import org.springframework.batch.item.UnexpectedInputException;
//import org.springframework.batch.item.file.FlatFileItemReader;
//
//import com.infosys.test.model.Employee;
//
//public class EmployeeItemReader extends FlatFileItemReader<Employee> implements ItemReader<Employee>{
//	
//	private Employee employee = null;
//	
//	private ItemReader<String> itemReader;
//	
//	@Override
//	public Employee read() throws Exception, UnexpectedInputException,
//	ParseException {
//		
//		String record = itemReader.read();
//		employee = new Employee();
//		if (Objects.isNull(record)) {
//            return null;
//        }
//        if(record.startsWith("BATCH")) {
//			return null;
//		}
//        
//        System.out.println("record read is "+record);
////		while(employeeList.size() < groupSize) {
////	        
////	        if (Objects.isNull(record)) {
////	            break;
////	        }
////	        if(record.startsWith("BATCH")) {
////				break;
////			}
//	        String[] employeeRecord = record.split(",");
//	        
//	        employee.setEmployeeNumber(Long.parseLong(employeeRecord[0]));
//	        employee.setEmployeeName(employeeRecord[1]);
//	        employee.setEmployeeSection(employeeRecord[2]);
//	        employee.setEmployeeAddress(employeeRecord[3]);
//	        employee.setEmployeeExperience(Integer.parseInt(employeeRecord[4]));
//	        employee.setEmployeeSalary(Double.parseDouble(employeeRecord[5]));
//	        employee.setEmployeeAnnualPay(Double.parseDouble(employeeRecord[6]));
//	        employee.setEmployeeBonus(Double.parseDouble(employeeRecord[7]));
//	        
////	        employeeList.add(employee);
////	    }
//
////	    if (employeeList.isEmpty()) {
////	        return null;
////	    }
//		
//	        System.out.println("Employee object is :"+ employee);
//		return employee;
//	}
//	
//	public Employee getEmployeeList() {
//		return employee;
//	}
//	
//	
//	public void setEmployeeList(Employee employee) {
//		this.employee = employee;
//	}
//
//}
