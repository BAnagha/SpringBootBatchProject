package com.infosys.test.batchconfig;

import java.util.List;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.infosys.test.model.Employee;

public class EmployeeItemWriter implements ItemWriter<Employee>{

	@Autowired
	RabbitTemplate rabbitTemplate;

	@Override
	public void write(List<? extends Employee> employees) {
		try {
			System.out.println(rabbitTemplate.getRoutingKey());
			for(Employee employee: employees) {
				System.out.println("New details are : "+ employee.getEmployeeSalary() + " "+ employee.getEmployeeAnnualPay() + " "+ employee.getEmployeeBonus());
				rabbitTemplate.convertAndSend(employee);
			}
		}catch(AmqpException e) {
			System.out.println("exception while adding to queue "+ e);
		}catch(Exception ex) {
			System.out.println("Oops! Exception caught! "+ ex);
		}

	}




}
