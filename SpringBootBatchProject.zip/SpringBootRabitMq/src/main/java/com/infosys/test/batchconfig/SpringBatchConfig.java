//package com.infosys.test.batchconfig;
//
//import org.springframework.batch.core.Job;
//import org.springframework.batch.core.Step;
//import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
//import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
//import org.springframework.batch.core.launch.support.RunIdIncrementer;
//import org.springframework.batch.item.ItemProcessor;
//import org.springframework.batch.item.ItemReader;
//import org.springframework.batch.item.ItemWriter;
//import org.springframework.batch.item.file.FlatFileItemReader;
//import org.springframework.batch.item.file.LineMapper;
//import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
//import org.springframework.batch.item.file.mapping.DefaultLineMapper;
//import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.core.io.Resource;
//
//import com.infosys.test.model.Employee;
//
//@Configuration
//public class SpringBatchConfig {
//
//	@Bean
//	public Job job(JobBuilderFactory jobBuilderFactory, StepBuilderFactory stepBuilderFactory,
//			ItemReader<Employee> itemReader,
//			ItemWriter<Employee> itemWriter, 
//			ItemProcessor<Employee, Employee> itemProcessor) {
//
//
//		Step step = stepBuilderFactory.get("employee-file-load")
//				.<Employee,Employee>chunk(5)
//				.reader(itemReader)
//				.processor(itemProcessor)
//				.writer(itemWriter)
//				.build();
//
//		return jobBuilderFactory.get("employee-batch")
//				.incrementer(new RunIdIncrementer())
//				.start(step)
//				.build(); 
//
//	}
//	
//	
//	@Bean
//	public FlatFileItemReader<Employee> fileItemReader(@Value("${input}")Resource resource){
//		FlatFileItemReader<Employee> flatFileItemReader = new FlatFileItemReader<Employee>();
//		flatFileItemReader.setResource(resource);
//		flatFileItemReader.setName("csv-reader");
//		flatFileItemReader.setLinesToSkip(1);
//		flatFileItemReader.setLineMapper(lineMapper());
//		
//		return flatFileItemReader;
//	}
//
//	@Bean
//	private LineMapper<Employee> lineMapper() {
//		
//		DefaultLineMapper<Employee> defaultLineMapper = new DefaultLineMapper<Employee>();
//		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
//		lineTokenizer.setDelimiter(",");
//		lineTokenizer.setNames(new String[] {"Employee number","Employee name","Employee section","Employee address","Employee experience"});
//		
//		
//		BeanWrapperFieldSetMapper<Employee> beanWrapperFieldSetMapper = new BeanWrapperFieldSetMapper<Employee>();
//		defaultLineMapper.setLineTokenizer(lineTokenizer) ;
//		defaultLineMapper.setFieldSetMapper(beanWrapperFieldSetMapper);
//		
//		return defaultLineMapper;
//	}
//
//}
