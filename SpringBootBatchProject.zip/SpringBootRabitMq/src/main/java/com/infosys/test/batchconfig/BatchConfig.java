package com.infosys.test.batchconfig;

import java.util.Arrays;

import javax.sql.DataSource;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.LineTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.batch.item.support.CompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.client.RestTemplate;

import com.infosys.test.model.Employee;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

	public final static String queueName = "employee-queue";

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	public DataSource dataSource;

	@Bean
	public DataSource datasource() {
		final DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost:3306/springbatch?useSSL=false&serverTimezone=UTC");
		dataSource.setUsername("root");
		dataSource.setPassword("Qwerty@1234");
		return dataSource;
	}

	@Bean
	public ConnectionFactory rabbitMqconnection() {
		final CachingConnectionFactory rabbitConnectionFactory = new CachingConnectionFactory();
		rabbitConnectionFactory.setHost("localhost");
		rabbitConnectionFactory.setPort(5672);
		rabbitConnectionFactory.setUsername("guest");
		rabbitConnectionFactory.setPassword("guest");
		return rabbitConnectionFactory;
	}

	@Bean
	public Queue employeeQueue() {
		return new Queue(queueName,false);
	}

	@Bean
	public Queue replyQueue() {
		return new Queue("employee.reply.queue");
	}

	@Bean
	Binding binding() {
		return BindingBuilder.bind(employeeQueue()).to(new DirectExchange("amq.direct")).with("");
	}
	@Bean
	public RabbitTemplate rabbitTemplate() {
		RabbitTemplate rabbitTemplate = new RabbitTemplate(this.rabbitMqconnection());
		rabbitTemplate.setDefaultReceiveQueue(queueName);
		rabbitTemplate.setReplyAddress("reply/routeReply");
		rabbitTemplate.setRoutingKey("");
		rabbitTemplate.setExchange("amq.direct");
		return rabbitTemplate;
	}

	@Bean
	public FlatFileItemReader<Employee> reader(){
		FlatFileItemReader<Employee> reader = new FlatFileItemReader<Employee>();
		reader.setResource(new ClassPathResource("employeedata.csv"));
		reader.setLinesToSkip(1);

		LineMapper<Employee> lineMapper = createLineMapper();
		reader.setLineMapper(lineMapper);

		return reader;
	}

	//	@Bean
	//	public FlatFileItemReader<Employee> reader(){
	//		EmployeeItemReader employeeItemReader = new EmployeeItemReader();
	//		employeeItemReader.setResource((new ClassPathResource("employeedata.csv")));
	//		employeeItemReader.setLinesToSkip(1);
	//
	//		LineMapper<Employee> lineMapper = createLineMapper();
	//		employeeItemReader.setLineMapper(lineMapper);
	//
	//		return employeeItemReader;
	//	}


	private LineMapper<Employee> createLineMapper() {

		DefaultLineMapper<Employee> defaultLineMapper = new DefaultLineMapper<Employee>();

		//		PatternMatchingCompositeLineMapper<Employee> mapper = new PatternMatchingCompositeLineMapper<Employee>();

//		PatternMatchingCompositeLineTokenizer patternMatchingCompositeLineTokenizer = new PatternMatchingCompositeLineTokenizer();

		//		Map<String, LineTokenizer> tokenizers = new HashMap<String, LineTokenizer>();
		//		tokenizers.put("*", createLineTokenizer());
		//		tokenizers.put("BATCH*", itemCountLineTokenizer());

//		patternMatchingCompositeLineTokenizer.setTokenizers(tokenizers);

		LineTokenizer lineTokenizer = createLineTokenizer();
		defaultLineMapper.setLineTokenizer(lineTokenizer);

		FieldSetMapper<Employee> fieldSetMapper = createEmployeeInfoMapper();
		defaultLineMapper.setFieldSetMapper(fieldSetMapper);
		return defaultLineMapper;
	}


	private FieldSetMapper<Employee> createEmployeeInfoMapper() {
		BeanWrapperFieldSetMapper<Employee> beanWrapperFieldSetMapper = new BeanWrapperFieldSetMapper<Employee>();
		beanWrapperFieldSetMapper.setTargetType(Employee.class);

		return beanWrapperFieldSetMapper;
	}

	public LineTokenizer itemCountLineTokenizer() {
		FixedLengthTokenizer tokenizer = new FixedLengthTokenizer();
		tokenizer.setColumns(new Range[] { new Range(1, 18), new Range(22, 24)});
		//tokenizer.setNames(new String[] { "batchName", "noOfRecords"});
		return tokenizer;
	}

	private LineTokenizer createLineTokenizer() {
		DelimitedLineTokenizer delimitedLineTokenizer = new DelimitedLineTokenizer();
		delimitedLineTokenizer.setDelimiter(",");
		delimitedLineTokenizer.setNames(new String[] {"employeeNumber","employeeName","employeeSection","employeeAddress","employeeExperience"});

		return delimitedLineTokenizer;
	}

	@Bean
	public EmployeeItemProcessor processor() {
		return new EmployeeItemProcessor();
	}


	@Bean
	public JdbcBatchItemWriter<Employee> jdbcWriter(){
		JdbcBatchItemWriter<Employee> jdbcWriter = new JdbcBatchItemWriter<Employee>();
		jdbcWriter.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<Employee>());
		jdbcWriter.setSql("INSERT into employee (employeeNumber,employeeName, employeeSection,employeeAddress,employeeExperience,employeeSalary,employeeAnnualPay,employeeBonus) "
				+ "values (:employeeNumber,:employeeName,:employeeSection,:employeeAddress,:employeeExperience,:employeeSalary,:employeeAnnualPay,:employeeBonus)");
		jdbcWriter.setDataSource(dataSource);
		return jdbcWriter;
	}

	@Bean
	public ItemWriter<Employee> amqpItemWriter(){

		return new EmployeeItemWriter();
	}

	public CompositeItemWriter<Employee> writer(){
		CompositeItemWriter<Employee> writer = new CompositeItemWriter<Employee>();
		writer.setDelegates(Arrays.asList(jdbcWriter(), amqpItemWriter()));
		return writer;
	}


	@Bean
	public Step step1() {
		return this.stepBuilderFactory.get("step1").<Employee,Employee>chunk(3)
				.reader(reader())
				.processor(processor())
				.writer(writer())
				.build();
	}

	@Bean
	public Job importEmployeeJob() {
		return this.jobBuilderFactory.get("importEmployeeJob")
				.incrementer(new RunIdIncrementer())
				.flow(step1())
				.end()
				.build();
	}

	//	@Bean
	//	@LoadBalanced
	//	public WebClient.Builder loadBalancedWebClientBuilder() {
	//	    return WebClient.builder();
	//	}

	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
