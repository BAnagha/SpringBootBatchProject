package com.infosys.test.model;

import java.io.Serializable;

public class Employee implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long employeeNumber;
	private String employeeName;
	private String employeeSection;
	private String employeeAddress;
	private int employeeExperience;
	private double employeeSalary;
	private double employeeAnnualPay;
	private double employeeBonus;
	
	public Employee() {
		super();
	}

	public Employee(long employeeNumber, String employeeName, String employeeSection, String employeeAddress,
			int employeeExperience, double employeeSalary, double employeeAnnualPay, double employeeBonus) {
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.employeeSection = employeeSection;
		this.employeeAddress = employeeAddress;
		this.employeeExperience = employeeExperience;
		this.employeeSalary = employeeSalary;
		this.employeeAnnualPay = employeeAnnualPay;
		this.employeeBonus = employeeBonus;
	}
	
	public long getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(long employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeSection() {
		return employeeSection;
	}
	public void setEmployeeSection(String employeeSection) {
		this.employeeSection = employeeSection;
	}
	public String getEmployeeAddress() {
		return employeeAddress;
	}
	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}
	public int getEmployeeExperience() {
		return employeeExperience;
	}
	public void setEmployeeExperience(int employeeExperience) {
		this.employeeExperience = employeeExperience;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public double getEmployeeAnnualPay() {
		return employeeAnnualPay;
	}
	public void setEmployeeAnnualPay(double employeeAnnualPay) {
		this.employeeAnnualPay = employeeAnnualPay;
	}
	public double getEmployeeBonus() {
		return employeeBonus;
	}
	public void setEmployeeBonus(double employeeBonus) {
		this.employeeBonus = employeeBonus;
	}
	
	@Override
	public String toString() {
		return "Employee [employeeNumber=" + employeeNumber + ", employeeName=" + employeeName + ", employeeSection="
				+ employeeSection + ", employeeAddress=" + employeeAddress + ", employeeExperience="
				+ employeeExperience + ", employeeSalary=" + employeeSalary + ", employeeAnnualPay=" + employeeAnnualPay
				+ ", employeeBonus=" + employeeBonus + "]";
	}
	
	
}
