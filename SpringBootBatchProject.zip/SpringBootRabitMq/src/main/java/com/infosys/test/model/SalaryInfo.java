package com.infosys.test.model;

public class SalaryInfo {
	
	private long employeeNumber;
	private double employeeSalary;
	private double employeeAnnualPay;
	private double employeeBonus;
	
	
	
	public SalaryInfo() {
		super();
	}

	public SalaryInfo(long employeeNumber, double employeeSalary, double employeeAnnualPay, double employeeBonus) {
		super();
		this.employeeNumber = employeeNumber;
		this.employeeSalary = employeeSalary;
		this.employeeAnnualPay = employeeAnnualPay;
		this.employeeBonus = employeeBonus;
	}
	
	public long getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(long employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public double getEmployeeAnnualPay() {
		return employeeAnnualPay;
	}
	public void setEmployeeAnnualPay(double employeeAnnualPay) {
		this.employeeAnnualPay = employeeAnnualPay;
	}
	public double getEmployeeBonus() {
		return employeeBonus;
	}
	public void setEmployeeBonus(double employeeBonus) {
		this.employeeBonus = employeeBonus;
	}
	
	@Override
	public String toString() {
		return "SalaryInfo [employeeNumber=" + employeeNumber + ", employeeSalary=" + employeeSalary
				+ ", employeeAnnualPay=" + employeeAnnualPay + ", employeeBonus=" + employeeBonus + "]";
	}
}
