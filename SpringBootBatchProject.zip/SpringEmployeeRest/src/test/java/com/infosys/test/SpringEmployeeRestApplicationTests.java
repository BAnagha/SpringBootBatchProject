package com.infosys.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.infosys.test.controller.EmployeeController;
import com.infosys.test.model.SalaryInfo;
import com.infosys.test.service.SalaryInfoService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = EmployeeController.class)
public class SpringEmployeeRestApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private SalaryInfoService studentService;

	SalaryInfo salaryInfo = new SalaryInfo(678989, 9000, 108000, 9000);

	@Test
	public void retrieveDetailsForCourse() throws Exception {

		Mockito.when(
				studentService.fetchSalaryInfo(Mockito.anyLong())).thenReturn(salaryInfo);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"http://employee-salary-info/employee/salaryInfo/678989").accept(
				MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println(result.getResponse());
		String expected = "{employeeNumber: 678989,employeeSalary: 9000,employeeAnnualPay: 108000,employeeBonus: 9000}";

		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);
	}

}
