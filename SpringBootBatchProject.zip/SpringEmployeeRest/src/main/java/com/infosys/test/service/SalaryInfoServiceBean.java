package com.infosys.test.service;

import javax.annotation.ManagedBean;

import org.springframework.beans.factory.annotation.Autowired;

import com.infosys.test.dao.SalaryInfoDao;
import com.infosys.test.model.SalaryInfo;

@ManagedBean
public class SalaryInfoServiceBean implements SalaryInfoService{

	
	@Autowired
	public SalaryInfoDao salaryInfoDao;
	
	@Override
	public SalaryInfo fetchSalaryInfo(long employeeId) {
		
		return salaryInfoDao.fetchSalaryInfo(employeeId);
		
	}

}
