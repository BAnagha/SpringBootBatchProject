package com.infosys.test.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class MySQLJDBCUtil {

	/**
	 * Get database connection
	 *
	 * @return a Connection object
	 * @throws SQLException
	 */
	public static Connection getConnection() throws SQLException {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			// assign db parameters
			String url = "jdbc:mysql://localhost:3306/springbatch?serverTimezone=UTC";
			String user = "root";
			String password = "Qwerty@1234";

			// create a connection to the database
			conn = DriverManager.getConnection(url, user, password);
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}

}