package com.infosys.test.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.annotation.ManagedBean;

import com.infosys.test.model.SalaryInfo;
import com.infosys.test.util.MySQLJDBCUtil;

@ManagedBean
public class SalaryInfoDao {

	public SalaryInfo fetchSalaryInfo(long employeeId) {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		SalaryInfo salaryInfo = null;
		try {
			conn = MySQLJDBCUtil.getConnection();
			if(conn !=null) {
				preparedStatement = conn.prepareStatement("Select * from salaryinfo where employeeNumber = ?");
				preparedStatement.setLong(1, employeeId);
				ResultSet resultSet = preparedStatement.executeQuery();
				while(resultSet.next())
				{

					salaryInfo = new SalaryInfo(resultSet.getLong("employeeNumber"), 
										resultSet.getDouble("employeeSalary"),
										resultSet.getDouble("employeeAnnualPay"), 
										resultSet.getDouble("employeeBonus"));
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return salaryInfo;
	}

}
