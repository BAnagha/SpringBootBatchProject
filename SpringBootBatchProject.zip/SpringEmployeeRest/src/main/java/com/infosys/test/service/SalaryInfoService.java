package com.infosys.test.service;

import com.infosys.test.model.SalaryInfo;

public interface SalaryInfoService {

	SalaryInfo fetchSalaryInfo(long employeeId);

}
