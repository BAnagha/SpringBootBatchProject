package com.infosys.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.test.model.SalaryInfo;
import com.infosys.test.service.SalaryInfoService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	public SalaryInfoService salaryInfoService;
	
	@RequestMapping(value = "/salaryInfo/{employeeId}", method = RequestMethod.GET)
	public SalaryInfo fetchSalaryInfo(@PathVariable long employeeId) {
		
		System.out.println("Fetching salary infos ....");
		SalaryInfo salaryInfo = salaryInfoService.fetchSalaryInfo(employeeId);
		if(salaryInfo == null) {
			return salaryInfo;
		}
		System.out.println("Got salary info..."+ salaryInfo);
		return salaryInfo;
		
		
	}
}
